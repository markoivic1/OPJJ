package hr.fer.zemris.java.custom.scripting.nodes;

/**
 * Used as a head node in a node tree.
 *
 * @author Marko Ivić
 */
public class DocumentNode extends Node {
    public void accept(INodeVisitor visitor) {
        visitor.visitDocumentNode(this);
    }
}
