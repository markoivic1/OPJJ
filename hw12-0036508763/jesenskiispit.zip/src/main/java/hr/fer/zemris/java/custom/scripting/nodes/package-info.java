/**
 * Package contains all of the defined nodes.
 *
 * @author Marko Ivić
 * @version 1.0.0
 */
package hr.fer.zemris.java.custom.scripting.nodes;