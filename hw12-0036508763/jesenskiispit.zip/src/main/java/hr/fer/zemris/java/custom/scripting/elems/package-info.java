/**
 * Package that has all the elements needed for the current {@link hr.fer.zemris.java.custom.scripting.parser.SmartScriptParser}.
 *
 * @author Marko Ivić
 * @version 1.0.0
 */
package hr.fer.zemris.java.custom.scripting.elems;