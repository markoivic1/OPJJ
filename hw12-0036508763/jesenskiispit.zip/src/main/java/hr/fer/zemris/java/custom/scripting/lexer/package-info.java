/**
 * Package which defines classes needed for a lexer.
 *
 * @author Marko Ivić
 * @version 1.0.0
 */
package hr.fer.zemris.java.custom.scripting.lexer;